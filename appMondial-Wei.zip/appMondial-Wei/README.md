# appMondial

python main.py -h
python main.py -nom John -tel 471371916 -dh "2023-12-12 14:14" -nbr 4 -TC eu -pmr 4 -bb 5